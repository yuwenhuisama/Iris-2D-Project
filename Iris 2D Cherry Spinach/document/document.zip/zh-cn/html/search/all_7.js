var searchData=
[
  ['setangle',['SetAngle',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a3fdbc5131b10eb0cb544df0beee82da2',1,'Iris2D::IrisSprite']]],
  ['setbitmap',['SetBitmap',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a17609cfcb89b4ea714389c40f143c7af',1,'Iris2D::IrisSprite']]],
  ['setmirror',['SetMirror',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a3ce55ee044b8345e93f8dfd45f23c72f',1,'Iris2D::IrisSprite']]],
  ['setopacity',['SetOpacity',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a8f32660ac464af824864c2af8c883039',1,'Iris2D::IrisSprite']]],
  ['setox',['SetOX',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#ae4b2cbedd03a92ac0b68b9e701df2e68',1,'Iris2D::IrisSprite']]],
  ['setoy',['SetOY',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a6dba8492659c67a9c09359ed321a89b3',1,'Iris2D::IrisSprite']]],
  ['setvisible',['SetVisible',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#aae4592abf843276138b5805eb030575e',1,'Iris2D::IrisSprite']]],
  ['setx',['SetX',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#adfabb55dba020af9fe324d4abfa7f07a',1,'Iris2D::IrisSprite']]],
  ['sety',['SetY',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a8064039bfeb3a364a8abeae7265cd429',1,'Iris2D::IrisSprite']]],
  ['setz',['SetZ',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a284d2af8d27d8fb72718e9554e0e90d9',1,'Iris2D::IrisSprite']]],
  ['setzoomx',['SetZoomX',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a0c7c13b0d3ec355a09e3c9c2ccc9d91e',1,'Iris2D::IrisSprite']]],
  ['setzoomy',['SetZoomY',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a316b2fbf2d0ecb1a1cd5b7bb95d62f05',1,'Iris2D::IrisSprite']]]
];
