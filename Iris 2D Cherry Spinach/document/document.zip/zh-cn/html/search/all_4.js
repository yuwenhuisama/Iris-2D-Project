var searchData=
[
  ['nshowcmd',['nShowCmd',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#a45353664bb0d0719cb06eb7763263d7d',1,'Iris2D::IrisApplication::IrisAppStartInfo']]]
];
