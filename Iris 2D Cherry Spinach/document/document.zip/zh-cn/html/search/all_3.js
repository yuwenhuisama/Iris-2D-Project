var searchData=
[
  ['m_5fhinstance',['m_hInstance',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#ab52c3d4447fe5c14dbd0f6839dd05032',1,'Iris2D::IrisApplication::IrisAppStartInfo']]],
  ['m_5fnheight',['m_nHeight',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#a05180868d302caaeed1ea93b9443be3b',1,'Iris2D::IrisApplication::IrisAppStartInfo']]],
  ['m_5fnwidth',['m_nWidth',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#a6bc24eb8432766a73244dfa4dbebab2b',1,'Iris2D::IrisApplication::IrisAppStartInfo']]],
  ['m_5fnx',['m_nX',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#af28e48cc9ed52f3e6ed6e9e5c464f6b7',1,'Iris2D::IrisApplication::IrisAppStartInfo']]],
  ['m_5fny',['m_nY',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#a451b1ba8aedbae08e32ecc379307ca93',1,'Iris2D::IrisApplication::IrisAppStartInfo']]],
  ['m_5fpffunc',['m_pfFunc',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#a33e7344a1e119e2db1e1a185dd1174f0',1,'Iris2D::IrisApplication::IrisAppStartInfo']]],
  ['m_5fwstrtitle',['m_wstrTitle',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html#a18a045ecc35ff343a38da429c2e59cdf',1,'Iris2D::IrisApplication::IrisAppStartInfo']]]
];
