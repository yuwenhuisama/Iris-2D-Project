var searchData=
[
  ['initialize',['Initialize',['../de/dbd/class_iris2_d_1_1_iris_application.html#a84f3ddebb3a3ffb0c172bd41fb952e1a',1,'Iris2D::IrisApplication::Initialize(HINSTANCE hInstance, unsigned int nWidth, unsigned int nHeight, GameFunc pfGameFunc, const std::wstring &amp;wszTitle)'],['../de/dbd/class_iris2_d_1_1_iris_application.html#ac20656815694f980fccfc4369727a9a9',1,'Iris2D::IrisApplication::Initialize(const IrisAppStartInfo *pInfo)']]],
  ['instance',['Instance',['../de/dbd/class_iris2_d_1_1_iris_application.html#ab2a9826c10d90732f398859782817f8e',1,'Iris2D::IrisApplication::Instance()'],['../d6/d73/class_iris2_d_1_1_iris_graphics.html#a25533fd69478336d60c5b1f639802d3a',1,'Iris2D::IrisGraphics::Instance()']]],
  ['isinitiatlize',['IsInitiatlize',['../de/dbd/class_iris2_d_1_1_iris_application.html#ab7a5b7f956f23d3fb3d2ee0de573cb53',1,'Iris2D::IrisApplication']]],
  ['isquited',['IsQuited',['../de/dbd/class_iris2_d_1_1_iris_application.html#ae9760ff496a4c80f96ad49331407c2e4',1,'Iris2D::IrisApplication']]],
  ['isrunning',['IsRunning',['../de/dbd/class_iris2_d_1_1_iris_application.html#a795cea1f5d8112a7db7d6429f306a5ff',1,'Iris2D::IrisApplication']]],
  ['isuninitialized',['IsUninitialized',['../de/dbd/class_iris2_d_1_1_iris_application.html#a1035e03a186b934ecf57371e42475eea',1,'Iris2D::IrisApplication']]]
];
