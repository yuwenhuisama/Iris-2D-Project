var searchData=
[
  ['create',['Create',['../d6/d85/class_iris2_d_1_1_iris_bitmap.html#ac9d31fd83b64c4051e1474eb7322442f',1,'Iris2D::IrisBitmap::Create(const std::wstring &amp;wstrFileName, IrisResult *_rParam=nullptr)'],['../d6/d85/class_iris2_d_1_1_iris_bitmap.html#a42a6c58440df5bb965a2d299cd3620e4',1,'Iris2D::IrisBitmap::Create(unsigned int nWidth, unsigned int nHeight, IrisResult *_rParam=nullptr)'],['../df/dc5/class_iris2_d_1_1_iris_sprite.html#ab68ea873fcd8521324c8497455dee852',1,'Iris2D::IrisSprite::Create()']]]
];
