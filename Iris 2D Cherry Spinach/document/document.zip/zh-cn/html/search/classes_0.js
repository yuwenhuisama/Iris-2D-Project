var searchData=
[
  ['irisapplication',['IrisApplication',['../de/dbd/class_iris2_d_1_1_iris_application.html',1,'Iris2D']]],
  ['irisappstartinfo',['IrisAppStartInfo',['../d4/d29/struct_iris2_d_1_1_iris_application_1_1_iris_app_start_info.html',1,'Iris2D::IrisApplication']]],
  ['irisbitmap',['IrisBitmap',['../d6/d85/class_iris2_d_1_1_iris_bitmap.html',1,'Iris2D']]],
  ['irisgraphics',['IrisGraphics',['../d6/d73/class_iris2_d_1_1_iris_graphics.html',1,'Iris2D']]],
  ['irissprite',['IrisSprite',['../df/dc5/class_iris2_d_1_1_iris_sprite.html',1,'Iris2D']]]
];
