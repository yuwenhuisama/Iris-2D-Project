var searchData=
[
  ['release',['Release',['../de/dbd/class_iris2_d_1_1_iris_application.html#a486d999a8d9e96f21b9d064d10d15b96',1,'Iris2D::IrisApplication::Release()'],['../d6/d85/class_iris2_d_1_1_iris_bitmap.html#a30f09c40ae048de40f06c0a1d6575441',1,'Iris2D::IrisBitmap::Release()'],['../df/dc5/class_iris2_d_1_1_iris_sprite.html#aa225c6483e0282375187b092ea0cecf9',1,'Iris2D::IrisSprite::Release()']]],
  ['run',['Run',['../de/dbd/class_iris2_d_1_1_iris_application.html#ae6bb59365978c945201fd8cf82105e4f',1,'Iris2D::IrisApplication']]]
];
