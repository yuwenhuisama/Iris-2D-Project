var searchData=
[
  ['getangle',['GetAngle',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#aef46b946bf5f46465ea164debdc78e57',1,'Iris2D::IrisSprite']]],
  ['getheight',['GetHeight',['../d6/d85/class_iris2_d_1_1_iris_bitmap.html#ad97028fda44cce4622d8ab78d8ba16b9',1,'Iris2D::IrisBitmap']]],
  ['getmirror',['GetMirror',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a5c4fa95fdadbb42ec65047b87786ec51',1,'Iris2D::IrisSprite']]],
  ['getopacity',['GetOpacity',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a59358690f1becb15facd176a9bba4096',1,'Iris2D::IrisSprite']]],
  ['getox',['GetOX',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a134ad89bea2b664a912574737bd418e5',1,'Iris2D::IrisSprite']]],
  ['getoy',['GetOY',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#adfdf12a18ff5237e1b27b63c2a27adaf',1,'Iris2D::IrisSprite']]],
  ['gettimedelta',['GetTimeDelta',['../de/dbd/class_iris2_d_1_1_iris_application.html#a3b8f4de1902aeda08acbe243aad34f15',1,'Iris2D::IrisApplication']]],
  ['getvisible',['GetVisible',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#afb65bc13767cb566233cf4c14b4288bd',1,'Iris2D::IrisSprite']]],
  ['getwidth',['GetWidth',['../d6/d85/class_iris2_d_1_1_iris_bitmap.html#a5bf259139daf86b07d8f0ff8dad44302',1,'Iris2D::IrisBitmap']]],
  ['getx',['GetX',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a6de92be964427290ad6daa0ee294cf21',1,'Iris2D::IrisSprite']]],
  ['gety',['GetY',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#afe8423cb0d34987c87f020ba3ba34b67',1,'Iris2D::IrisSprite']]],
  ['getz',['GetZ',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#ad4966003c9bf2ad093db013de626e44c',1,'Iris2D::IrisSprite']]],
  ['getzoomx',['GetZoomX',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a1cb9fb2549f00ef1efab204f0d222aeb',1,'Iris2D::IrisSprite']]],
  ['getzoomy',['GetZoomY',['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a350aab21a9e40f7d26b8d757d26e4df2',1,'Iris2D::IrisSprite']]]
];
