var searchData=
[
  ['update',['Update',['../d6/d73/class_iris2_d_1_1_iris_graphics.html#aa25debfc9a08d7084f48711a6bffdc4d',1,'Iris2D::IrisGraphics::Update()'],['../df/dc5/class_iris2_d_1_1_iris_sprite.html#a755c2896a54ad43d68db2993477b900a',1,'Iris2D::IrisSprite::Update()']]],
  ['updatenolock',['UpdateNoLock',['../d6/d73/class_iris2_d_1_1_iris_graphics.html#adbbca919748bfdd9b84958414debc588',1,'Iris2D::IrisGraphics']]]
];
